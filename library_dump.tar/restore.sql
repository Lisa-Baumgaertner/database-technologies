--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Library";
--
-- Name: Library; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Library" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'German_Germany.1252';


ALTER DATABASE "Library" OWNER TO postgres;

\connect "Library"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Library; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Library";


ALTER SCHEMA "Library" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ADDRESS; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."ADDRESS" (
    "ADDRESS_ID" integer NOT NULL,
    "USER_ID" integer NOT NULL,
    "STREET" character varying(200) NOT NULL,
    "HOUSENUMBER" character varying(50) NOT NULL,
    "CITY" character varying(90) NOT NULL,
    "ZIP_CODE" character varying NOT NULL
);


ALTER TABLE "Library"."ADDRESS" OWNER TO postgres;

--
-- Name: ADDRESS_ADDRESS_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."ADDRESS" ALTER COLUMN "ADDRESS_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."ADDRESS_ADDRESS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: BOOK; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."BOOK" (
    "BOOK-ID" integer NOT NULL,
    "ISBN" character varying(64) NOT NULL,
    "BOOKTITLE" character varying(500) NOT NULL,
    "BOOKAUTHOR" character varying(200) NOT NULL,
    "PUBLISHER" character varying(400) NOT NULL,
    "YEAR_PUBLISHED" integer NOT NULL,
    "DESCRIPTION" character varying(10000) NOT NULL,
    "STATUS" character varying(100) NOT NULL,
    "KEYWORD_ID" integer NOT NULL,
    "THEME" character varying(100)
);


ALTER TABLE "Library"."BOOK" OWNER TO postgres;

--
-- Name: BOOK_BOOK-ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."BOOK" ALTER COLUMN "BOOK-ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."BOOK_BOOK-ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: CONTACT; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."CONTACT" (
    "CONTACT_ID" integer NOT NULL,
    "USER_ID" integer NOT NULL,
    "EMAIL" character varying(200),
    "PHONE" character varying(50),
    "MOBILE" character varying(30)
);


ALTER TABLE "Library"."CONTACT" OWNER TO postgres;

--
-- Name: CONTACT_CONTACT_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."CONTACT" ALTER COLUMN "CONTACT_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."CONTACT_CONTACT_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: KEYWORD; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."KEYWORD" (
    "KEYWORD_ID" integer NOT NULL,
    "KEYWORD" character varying(100) NOT NULL
);


ALTER TABLE "Library"."KEYWORD" OWNER TO postgres;

--
-- Name: KEYWORD_KEYWORD_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."KEYWORD" ALTER COLUMN "KEYWORD_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."KEYWORD_KEYWORD_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: LENDING; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."LENDING" (
    "LENDING_ID" integer NOT NULL,
    "BOOK_ID" integer NOT NULL,
    "USER_ID_BORROWER" integer NOT NULL,
    "USER_ID_WORKER" integer NOT NULL,
    "STATUS" character varying NOT NULL,
    "CHECKOUT_DATE" date NOT NULL,
    "RETURN_DATE" date NOT NULL,
    "DUE_DATE" date NOT NULL
);


ALTER TABLE "Library"."LENDING" OWNER TO postgres;

--
-- Name: LENDING_LENDING_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."LENDING" ALTER COLUMN "LENDING_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."LENDING_LENDING_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: PERSON; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."PERSON" (
    "USER_ID" integer NOT NULL,
    "FIRSTNAME" "char" NOT NULL,
    "LASTNAME" "char" NOT NULL,
    "BIRTHDATE" date NOT NULL,
    "GENDER" "char" NOT NULL,
    "ROLE" "char" NOT NULL
);


ALTER TABLE "Library"."PERSON" OWNER TO postgres;

--
-- Name: PERSON_USER_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."PERSON" ALTER COLUMN "USER_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."PERSON_USER_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: REVIEW; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."REVIEW" (
    "REVIEW_ID" integer NOT NULL,
    "BOOK_ID" integer NOT NULL,
    "USER_ID" integer NOT NULL,
    "REVIEW_TEXT" character varying(1000) NOT NULL,
    "REVIEW_DATE" date NOT NULL,
    "REVIEW_RATING" character varying(10) NOT NULL
);


ALTER TABLE "Library"."REVIEW" OWNER TO postgres;

--
-- Name: REVIEW_REVIEW_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."REVIEW" ALTER COLUMN "REVIEW_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."REVIEW_REVIEW_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: WAITLIST; Type: TABLE; Schema: Library; Owner: postgres
--

CREATE TABLE "Library"."WAITLIST" (
    "WAITLIST_ID" integer NOT NULL,
    "USER_ID" integer NOT NULL,
    "BOOK_ID" integer NOT NULL,
    "CHECKOUT_DATE" date NOT NULL,
    "RETURN_DATE" date NOT NULL,
    "STATUS" character varying NOT NULL
);


ALTER TABLE "Library"."WAITLIST" OWNER TO postgres;

--
-- Name: WAITLIST_WAITLIST_ID_seq; Type: SEQUENCE; Schema: Library; Owner: postgres
--

ALTER TABLE "Library"."WAITLIST" ALTER COLUMN "WAITLIST_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "Library"."WAITLIST_WAITLIST_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: ADDRESS; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."ADDRESS" ("ADDRESS_ID", "USER_ID", "STREET", "HOUSENUMBER", "CITY", "ZIP_CODE") FROM stdin;
\.
COPY "Library"."ADDRESS" ("ADDRESS_ID", "USER_ID", "STREET", "HOUSENUMBER", "CITY", "ZIP_CODE") FROM '$$PATH$$/4906.dat';

--
-- Data for Name: BOOK; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."BOOK" ("BOOK-ID", "ISBN", "BOOKTITLE", "BOOKAUTHOR", "PUBLISHER", "YEAR_PUBLISHED", "DESCRIPTION", "STATUS", "KEYWORD_ID", "THEME") FROM stdin;
\.
COPY "Library"."BOOK" ("BOOK-ID", "ISBN", "BOOKTITLE", "BOOKAUTHOR", "PUBLISHER", "YEAR_PUBLISHED", "DESCRIPTION", "STATUS", "KEYWORD_ID", "THEME") FROM '$$PATH$$/4903.dat';

--
-- Data for Name: CONTACT; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."CONTACT" ("CONTACT_ID", "USER_ID", "EMAIL", "PHONE", "MOBILE") FROM stdin;
\.
COPY "Library"."CONTACT" ("CONTACT_ID", "USER_ID", "EMAIL", "PHONE", "MOBILE") FROM '$$PATH$$/4908.dat';

--
-- Data for Name: KEYWORD; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."KEYWORD" ("KEYWORD_ID", "KEYWORD") FROM stdin;
\.
COPY "Library"."KEYWORD" ("KEYWORD_ID", "KEYWORD") FROM '$$PATH$$/4910.dat';

--
-- Data for Name: LENDING; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."LENDING" ("LENDING_ID", "BOOK_ID", "USER_ID_BORROWER", "USER_ID_WORKER", "STATUS", "CHECKOUT_DATE", "RETURN_DATE", "DUE_DATE") FROM stdin;
\.
COPY "Library"."LENDING" ("LENDING_ID", "BOOK_ID", "USER_ID_BORROWER", "USER_ID_WORKER", "STATUS", "CHECKOUT_DATE", "RETURN_DATE", "DUE_DATE") FROM '$$PATH$$/4916.dat';

--
-- Data for Name: PERSON; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."PERSON" ("USER_ID", "FIRSTNAME", "LASTNAME", "BIRTHDATE", "GENDER", "ROLE") FROM stdin;
\.
COPY "Library"."PERSON" ("USER_ID", "FIRSTNAME", "LASTNAME", "BIRTHDATE", "GENDER", "ROLE") FROM '$$PATH$$/4904.dat';

--
-- Data for Name: REVIEW; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."REVIEW" ("REVIEW_ID", "BOOK_ID", "USER_ID", "REVIEW_TEXT", "REVIEW_DATE", "REVIEW_RATING") FROM stdin;
\.
COPY "Library"."REVIEW" ("REVIEW_ID", "BOOK_ID", "USER_ID", "REVIEW_TEXT", "REVIEW_DATE", "REVIEW_RATING") FROM '$$PATH$$/4912.dat';

--
-- Data for Name: WAITLIST; Type: TABLE DATA; Schema: Library; Owner: postgres
--

COPY "Library"."WAITLIST" ("WAITLIST_ID", "USER_ID", "BOOK_ID", "CHECKOUT_DATE", "RETURN_DATE", "STATUS") FROM stdin;
\.
COPY "Library"."WAITLIST" ("WAITLIST_ID", "USER_ID", "BOOK_ID", "CHECKOUT_DATE", "RETURN_DATE", "STATUS") FROM '$$PATH$$/4914.dat';

--
-- Name: ADDRESS_ADDRESS_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."ADDRESS_ADDRESS_ID_seq"', 1, false);


--
-- Name: BOOK_BOOK-ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."BOOK_BOOK-ID_seq"', 1, false);


--
-- Name: CONTACT_CONTACT_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."CONTACT_CONTACT_ID_seq"', 1, false);


--
-- Name: KEYWORD_KEYWORD_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."KEYWORD_KEYWORD_ID_seq"', 1, false);


--
-- Name: LENDING_LENDING_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."LENDING_LENDING_ID_seq"', 1, false);


--
-- Name: PERSON_USER_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."PERSON_USER_ID_seq"', 1, false);


--
-- Name: REVIEW_REVIEW_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."REVIEW_REVIEW_ID_seq"', 1, false);


--
-- Name: WAITLIST_WAITLIST_ID_seq; Type: SEQUENCE SET; Schema: Library; Owner: postgres
--

SELECT pg_catalog.setval('"Library"."WAITLIST_WAITLIST_ID_seq"', 1, false);


--
-- Name: ADDRESS ADDRESS_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."ADDRESS"
    ADD CONSTRAINT "ADDRESS_pkey" PRIMARY KEY ("ADDRESS_ID");


--
-- Name: BOOK BOOK_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."BOOK"
    ADD CONSTRAINT "BOOK_pkey" PRIMARY KEY ("BOOK-ID");


--
-- Name: CONTACT CONTACT_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."CONTACT"
    ADD CONSTRAINT "CONTACT_pkey" PRIMARY KEY ("CONTACT_ID");


--
-- Name: KEYWORD KEYWORD_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."KEYWORD"
    ADD CONSTRAINT "KEYWORD_pkey" PRIMARY KEY ("KEYWORD_ID");


--
-- Name: LENDING LENDING_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."LENDING"
    ADD CONSTRAINT "LENDING_pkey" PRIMARY KEY ("LENDING_ID");


--
-- Name: PERSON PERSON_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."PERSON"
    ADD CONSTRAINT "PERSON_pkey" PRIMARY KEY ("USER_ID");


--
-- Name: REVIEW REVIEW_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."REVIEW"
    ADD CONSTRAINT "REVIEW_pkey" PRIMARY KEY ("REVIEW_ID");


--
-- Name: WAITLIST WAITLIST_pkey; Type: CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."WAITLIST"
    ADD CONSTRAINT "WAITLIST_pkey" PRIMARY KEY ("WAITLIST_ID");


--
-- Name: ADDRESS ADDRESS_USER_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."ADDRESS"
    ADD CONSTRAINT "ADDRESS_USER_ID_fkey" FOREIGN KEY ("USER_ID") REFERENCES "Library"."PERSON"("USER_ID") NOT VALID;


--
-- Name: BOOK BOOK_KEYWORD_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."BOOK"
    ADD CONSTRAINT "BOOK_KEYWORD_ID_fkey" FOREIGN KEY ("KEYWORD_ID") REFERENCES "Library"."KEYWORD"("KEYWORD_ID") NOT VALID;


--
-- Name: CONTACT CONTACT_USER_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."CONTACT"
    ADD CONSTRAINT "CONTACT_USER_ID_fkey" FOREIGN KEY ("USER_ID") REFERENCES "Library"."PERSON"("USER_ID") NOT VALID;


--
-- Name: LENDING LENDING_BOOK_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."LENDING"
    ADD CONSTRAINT "LENDING_BOOK_ID_fkey" FOREIGN KEY ("BOOK_ID") REFERENCES "Library"."BOOK"("BOOK-ID") NOT VALID;


--
-- Name: LENDING LENDING_USER_ID_BORROWER_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."LENDING"
    ADD CONSTRAINT "LENDING_USER_ID_BORROWER_fkey" FOREIGN KEY ("USER_ID_BORROWER") REFERENCES "Library"."PERSON"("USER_ID") NOT VALID;


--
-- Name: LENDING LENDING_USER_ID_WORKER_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."LENDING"
    ADD CONSTRAINT "LENDING_USER_ID_WORKER_fkey" FOREIGN KEY ("USER_ID_WORKER") REFERENCES "Library"."PERSON"("USER_ID") NOT VALID;


--
-- Name: REVIEW REVIEW_BOOK_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."REVIEW"
    ADD CONSTRAINT "REVIEW_BOOK_ID_fkey" FOREIGN KEY ("BOOK_ID") REFERENCES "Library"."BOOK"("BOOK-ID") NOT VALID;


--
-- Name: REVIEW REVIEW_USER_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."REVIEW"
    ADD CONSTRAINT "REVIEW_USER_ID_fkey" FOREIGN KEY ("USER_ID") REFERENCES "Library"."PERSON"("USER_ID") NOT VALID;


--
-- Name: WAITLIST WAITLIST_BOOK_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."WAITLIST"
    ADD CONSTRAINT "WAITLIST_BOOK_ID_fkey" FOREIGN KEY ("BOOK_ID") REFERENCES "Library"."BOOK"("BOOK-ID") NOT VALID;


--
-- Name: WAITLIST WAITLIST_USER_ID_fkey; Type: FK CONSTRAINT; Schema: Library; Owner: postgres
--

ALTER TABLE ONLY "Library"."WAITLIST"
    ADD CONSTRAINT "WAITLIST_USER_ID_fkey" FOREIGN KEY ("USER_ID") REFERENCES "Library"."PERSON"("USER_ID") NOT VALID;


--
-- PostgreSQL database dump complete
--

